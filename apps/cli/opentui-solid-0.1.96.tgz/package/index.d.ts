import { CliRenderer, type CliRendererConfig } from "@opentui/core";
import { type TestRendererOptions } from "@opentui/core/testing";
import type { JSX } from "./jsx-runtime";
export declare const render: (node: () => JSX.Element, rendererOrConfig?: CliRenderer | CliRendererConfig) => Promise<void>;
export declare const testRender: (node: () => JSX.Element, renderConfig?: TestRendererOptions) => Promise<{
    renderer: import("@opentui/core/testing").TestRenderer;
    mockInput: import("@opentui/core/testing").MockInput;
    mockMouse: import("@opentui/core/testing").MockMouse;
    renderOnce: () => Promise<void>;
    captureCharFrame: () => string;
    captureSpans: () => import("@opentui/core").CapturedFrame;
    resize: (width: number, height: number) => void;
}>;
export * from "./src/reconciler.js";
export * from "./src/elements/index.js";
export * from "./src/time-to-first-draw.js";
export * from "./src/plugins/slot.js";
export * from "./src/types/elements.js";
export { type JSX };
