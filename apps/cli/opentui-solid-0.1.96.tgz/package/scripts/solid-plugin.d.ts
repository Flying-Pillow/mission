import { type BunPlugin } from "bun";
export type ResolveImportPath = (specifier: string) => string | null;
export interface CreateSolidTransformPluginOptions {
    moduleName?: string;
    resolvePath?: ResolveImportPath;
}
export declare function ensureSolidTransformPlugin(input?: CreateSolidTransformPluginOptions): boolean;
export declare function resetSolidTransformPluginState(): void;
export declare function createSolidTransformPlugin(input?: CreateSolidTransformPluginOptions): BunPlugin;
declare const solidTransformPlugin: BunPlugin;
export default solidTransformPlugin;
