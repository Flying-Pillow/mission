import { ASCIIFontRenderable, BoxRenderable, CodeRenderable, DiffRenderable, InputRenderable, LineNumberRenderable, MarkdownRenderable, ScrollBoxRenderable, SelectRenderable, TabSelectRenderable, TextareaRenderable, TextNodeRenderable, TextRenderable, type RenderContext, type TextNodeOptions } from "@opentui/core";
import type { RenderableConstructor } from "../types/elements.js";
export * from "./hooks.js";
export * from "./extras.js";
export * from "./slot.js";
declare class SpanRenderable extends TextNodeRenderable {
    private readonly _ctx;
    constructor(_ctx: RenderContext | null, options: TextNodeOptions);
}
export declare const textNodeKeys: readonly ["span", "b", "strong", "i", "em", "u", "a"];
export type TextNodeKey = (typeof textNodeKeys)[number];
declare class TextModifierRenderable extends SpanRenderable {
    constructor(options: any, modifier?: TextNodeKey);
}
export declare class BoldSpanRenderable extends TextModifierRenderable {
    constructor(options: any);
}
export declare class ItalicSpanRenderable extends TextModifierRenderable {
    constructor(options: any);
}
export declare class UnderlineSpanRenderable extends TextModifierRenderable {
    constructor(options: any);
}
export declare class LineBreakRenderable extends SpanRenderable {
    constructor(_ctx: RenderContext | null, options: TextNodeOptions);
    add(): number;
}
export interface LinkOptions extends TextNodeOptions {
    href: string;
}
export declare class LinkRenderable extends SpanRenderable {
    constructor(_ctx: RenderContext | null, options: LinkOptions);
}
export declare const baseComponents: {
    box: typeof BoxRenderable;
    text: typeof TextRenderable;
    input: typeof InputRenderable;
    select: typeof SelectRenderable;
    textarea: typeof TextareaRenderable;
    ascii_font: typeof ASCIIFontRenderable;
    tab_select: typeof TabSelectRenderable;
    scrollbox: typeof ScrollBoxRenderable;
    code: typeof CodeRenderable;
    diff: typeof DiffRenderable;
    line_number: typeof LineNumberRenderable;
    markdown: typeof MarkdownRenderable;
    span: typeof SpanRenderable;
    strong: typeof BoldSpanRenderable;
    b: typeof BoldSpanRenderable;
    em: typeof ItalicSpanRenderable;
    i: typeof ItalicSpanRenderable;
    u: typeof UnderlineSpanRenderable;
    br: typeof LineBreakRenderable;
    a: typeof LinkRenderable;
};
type ComponentCatalogue = Record<string, RenderableConstructor>;
export declare const componentCatalogue: ComponentCatalogue;
/**
 * Extend the component catalogue with new renderable components
 *
 * @example
 * ```tsx
 * // Extend with an object of components
 * extend({
 *   consoleButton: ConsoleButtonRenderable,
 *   customBox: CustomBoxRenderable
 * })
 * ```
 */
export declare function extend<T extends ComponentCatalogue>(objects: T): void;
export declare function getComponentCatalogue(): ComponentCatalogue;
export type { ExtendedComponentProps, ExtendedIntrinsicElements, RenderableConstructor } from "../types/elements.js";
